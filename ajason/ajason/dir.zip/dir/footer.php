    </main>
    <footer class="row-full pad">
        <div class="row">
            <div class="grid-3">
                The Official Website of Alastair Paragas<br/>
                Email: alastairparagas@gmail.com<br/>
                Phone: (305)951-4410
            </div>
            <div class="grid-4">
                    This site was designed with Forfront Grid, a 12-column grid
                    system designed by Alastair Paragas. Want to use this same
                    awesome grid-system? Click here.
            </div>
            <div class="grid-4 offset-1">
                <span id="social-media">
                    <a href="http://facebook.com/alastairparagas" title="Catch me on Facebook!"><i class="fa fa-facebook"></i>Facebook</a>
                    <a href="http://twitter.com/alastairparagas" title="Tweet me on Twitter!"><i class="fa fa-twitter"></i>Twitter</a>
                    <a href="http://lnkd.in/pb4gbg" title="Link with me on LinkedIn!"><i class="fa fa-linkedin"></i>LinkedIn</a>
                    <a href="http://tumblr.com/aparagas" title="Tumble with me on Tumblr!"><i class="fa fa-tumblr"></i>Tumblr</a>
                    <a href="http://www.youtube.com/user/alastairparagas/videos" title="Watch me on Youtube"><i class="fa fa-youtube"></i>Youtube</a>
                </span>
            </div>
        </div>
    </footer>
    </body>
</html>


