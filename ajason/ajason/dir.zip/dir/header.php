<!DOCTYPE html>
<html>
    <head>
    	<script>
	    	function stillWorkin(){
			alert("This blog is still currently in development");
		}
    	</script>
        <title>Anil Jason - Programer/Hacker/Nerd</title>
        <meta name="author" content="Anil Jason" />
        <meta name="description" content="The personal website dedicated to log my personal projects and hacks." />
        <meta name="viewport" content="width=device-width, initial-scale=1.0;">
        <link rel="stylesheet" href="css/style.css" type="text/css" />
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato" type="text/css" />
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" type="text/css">
        
        
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.11.1-rc2/jquery.min.js"></script>
        <!--[if lt IE 9]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->
    </head>
    <body>
    
    <!--
    <header>
        <div class="row">
           
            <nav>
                <ul>
                    <li><a onClick='stillWorkin()' href="#"><i class="fa fa-home"></i>Home</a></li>
                    <li><a onClick='stillWorkin()' href="index.php"><i class="fa fa-folder-open"></i>Portfolio</a></li>
                    <li><a onClick='stillWorkin()' href="#"><i class="fa fa-leaf"></i>Biography</a></li>
                    <li><a onClick='stillWorkin()' href="#"><i class="fa fa-picture-o"></i>Inspiration</a></li>
                    <li><a onClick='stillWorkin()' href="#"><i class="fa fa-gears"></i>Resources</a></li>
                </ul>
            </nav>
        </div>
    </header>
    -->

    <main>