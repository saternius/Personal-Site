<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>jQuery UI Dialog - Default functionality</title>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
<link rel="stylesheet" href="/resources/demos/style.css">
<script>
$(function() {
$( "#dialog" ).dialog();
});
</script>
</head>
<body>
<div id="dialog" title="Basic dialog">
<iframe src='http://myrighttoplay.com' height='300' width='300'></iframe>

</div>
</body>
<p>Space Dexterity was by first start to finish project. It took me 3 days to make and was so fun it encouraged me to make more programs. I posted it on online and embeded mochi onto it and since 2010 has gotten well over 200,000 plays.</p>
				<object id='swf_game_object' classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,' 
			style='width:550px; height:400px; z-index:100;'>
				<param name='movie' value='http://www.myrighttoplay.com/swfs/space-dexterity.swf' />
				<param name='quality' value='medium' />
				<param name='wmode' value='transparent' />
			<embed id='swf_game_embed' src='http://www.myrighttoplay.com/swfs/space-dexterity.swf' style='width:550px; height:400px; z-index:100;' 
			quality='medium' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' wmode='transparent'></embed>
			</object>
</html>